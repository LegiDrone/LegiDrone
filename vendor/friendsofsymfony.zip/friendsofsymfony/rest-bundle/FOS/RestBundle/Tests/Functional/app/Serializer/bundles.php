<?php

return array(
    new \Symfony\Bundle\FrameworkBundle\FrameworkBundle(),
    new \FOS\RestBundle\FOSRestBundle(),
    new \FOS\RestBundle\Tests\Functional\Bundle\TestBundle\TestBundle()
);
